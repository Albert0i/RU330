set -x
/usr/local/bin/redis-cli --tls --cacert /usr/local/share/ca-certificates/ca.crt shutdown
