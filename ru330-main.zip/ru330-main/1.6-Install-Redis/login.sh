docker run -it redisuniversity/ru330-base /bin/bash
