docker build -f Dockerfile -t redisuniversity/ru330-base .
