docker build -f Dockerfile -t redisuniversity/ru330-tls-advanced .
